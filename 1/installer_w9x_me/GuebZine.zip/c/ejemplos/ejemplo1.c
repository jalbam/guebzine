#include <stdio.h>
#include <conio.h>
/* Comentario interno */
main()                   /* inicia el 'cuerpo' del programa donde lo escribiremos */
{                        /* Se�ala su lugar de apertura (MAIN) */
clrscr();                /* Limpia la pantalla: CLeaR SCReen. Similar al CLS del DOS y Basic. */
printf("Hola Mundo!!!"); /* Muestra el mensaje que esta entre comillas en pantalla */
getch();                 /* Realiza una pausa hasta que se pulse una tecla */
}                        /* Finaliza MAIN y el programa ya que no hay mas debajo */