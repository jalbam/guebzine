#include <stdio.h> /* Declaracion de la libreria stdio.h */
#include <conio.h> /* Declaracion de la libreria conio.h */

/* Comentario oculto que solo leemos nosotros */

int b=0; /* Declaramos una variable llamada b con el valor inicial de 0. Esta
	    podra ser utilizada en cualquier funcion ya que ha sido declarada
	    fuera */

main() 	      /* La primera funcion siempre ha de tener el nombre MAIN() */
	{     /* Abrimos la llave para indicar el contenido de la funcion */

		int a=0;  /* Declaramos la variable a con el valor 0. Esta
			     solo podra ser utilizada dentro de la funcion
			     donde se declara: MAIN() */

		clrscr();                         /* Limpiamos la pantalla */
		printf("\n\tHOLA MUNDO");         /* Bajamos una linea y
						     hacemos un tabulador e
						     imprimimos la frase*/
		printf("\nA = %d y B = %d",a,b);  /* Baja una linea e imprime
						     el contenido de la
						     variable A y B */
		getch();                          /* Hace una pausa hasta la
						     pulsacion de una tecla */

	}     /* Cerramos la llave del contenido de la funcion */


